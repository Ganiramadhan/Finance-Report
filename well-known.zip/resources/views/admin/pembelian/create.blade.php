@extends('layouts.admin.app', ['title' => 'Tambah Pembelian'])

@section('content')
    <div class="section-header">
        <h1>Tambah Pembelian</h1>
    </div>
    <hr />
    {{-- @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif --}}
    <form action="{{ route('pembelian.store') }}" method="POST">
        @csrf

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Kode Transaksi</label>
                    <input type="text" name="kd_transaksi" id="kd_transaksi" class="form-control"
                        placeholder="Kode Transaksi" required value="{{ old('kd_transaksi') }}">

                    @error('kd_transaksi')
                        <div class="alert alert-danger mt-2">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label">Jenis Produk</label>
                    <select class="form-control" id="product_id" name="product_id" required>
                        <option value="">Pilih Jenis Produk</option>
                        @foreach ($data_product as $item)
                            <option value="{{ $item->id }}" data-satuan="{{ $item->satuan }}"
                                data-harga="{{ $item->hrg_jual }}"
                                {{ old('product_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <input type="hidden" name="hrg_beli_satuan" id="hrg_beli_satuan" class="form-control"
                    placeholder="hrg_beli_satuan" required readonly value="{{ old('hrg_beli_satuan') }}">

                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="qty" id="qty" class="form-control" placeholder="Jumlah" required
                        value="{{ old('qty') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Satuan</label>
                    <input type="text" id="satuan" name="satuan" class="form-control" placeholder="Satuan" readonly
                        value="{{ old('satuan') }}">
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Harga</label>
                    <input type="text" name="total_harga" id="total_harga" class="form-control" placeholder="Total Harga"
                        readonly value="{{ old('hrg_jual') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Metode Pembayaran</label>
                    <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                        <option value="">Metode Pembayaran</option>
                        @foreach ($data_metode_pembayaran as $item)
                            <option value="{{ $item->id }}"
                                {{ old('metode_pembayaran_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->metode_pembayaran }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Supplier</label>
                    <select class="form-control" id="supplier_id" name="supplier_id" required>
                        <option value="">Supplier</option>
                        @foreach ($data_supplier as $item)
                            <option value="{{ $item->id }}" {{ old('supplier_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Belanja</label>
                    <input type="number" name="total_belanja" id="total_belanja" class="form-control"
                        placeholder="Total Belanja" required value="{{ old('total_belanja') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Diskon</label>
                    <input type="number" name="diskon" id="diskon" class="form-control" placeholder="Diskon" required
                        value="{{ old('diskon') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Total Bayar</label>
                    <input type="number" name="total_bayar" id="total_bayar" class="form-control" placeholder="Total Bayar"
                        required value="{{ old('total_bayar') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Pembayaran</label>
                    <input type="number" name="pembayaran" id="pembayaran" class="form-control" placeholder="Pembayaran"
                        required value="{{ old('pembayaran') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">Utang</label>
                    <input type="string" name="utang" id="utang" class="form-control" placeholder="Utang"
                        required value="{{ old('utang') }}">
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="keterangan" id="keterangan" class="form-control"
                        placeholder="Keterangan" required value="{{ old('keterangan') }}">
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control"
                        placeholder="Tanggal Transaksi" required value="{{ old('tanggal') }}">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="d-grid">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>

    <script>
        // ... Bagian JavaScript lainnya yang sudah Anda miliki tetap sama seperti sebelumnya
    </script>
@endsection


<script>
    function setKodePembelian() {
        document.getElementById('kd_transaksi').value = 'TPP-';
    }

    // Panggil fungsi setKodePembelian saat halaman dimuat
    window.onload = setKodePembelian;


    document.addEventListener("DOMContentLoaded", function() {
        var productSelect = document.getElementById("product_id");
        var satuanInput = document.getElementById("satuan");

        // Function to update the "Satuan" field based on the selected product
        function updateSatuan() {
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var satuan = selectedOption.getAttribute("data-satuan") || "";
            satuanInput.value = satuan;
        }

        // Event listener for changes in the selected product
        productSelect.addEventListener("change", function() {
            updateSatuan();
        });

        // Call the function to set the initial value
        updateSatuan();
    });

document.addEventListener("DOMContentLoaded", function() {
    var productSelect = document.getElementById("product_id");
    var qtyInput = document.getElementById("qty");
    var totalHargaInput = document.getElementById("total_harga");

    productSelect.addEventListener("change", function() {
        var selectedOption = productSelect.options[productSelect.selectedIndex];
        var selectedHarga = parseFloat(selectedOption.getAttribute("data-harga")) || 0;
        totalHargaInput.value = selectedHarga.toFixed(2);
    });

    qtyInput.addEventListener("input", function() {
        calculateTotalHarga();
    });

    function calculateTotalHarga() {
        var selectedOption = productSelect.options[productSelect.selectedIndex];
        var selectedHarga = parseFloat(selectedOption.getAttribute("data-harga")) || 0;
        totalHargaInput.value = selectedHarga.toFixed(2);
    }
});




    document.addEventListener("DOMContentLoaded", function() {
        var totalBelanjaInput = document.getElementById("total_belanja");
        var diskonInput = document.getElementById("diskon");
        var totalBayarInput = document.getElementById("total_bayar");

        totalBelanjaInput.addEventListener("input", calculateTotalBayar);
        diskonInput.addEventListener("input", calculateTotalBayar);

        function calculateTotalBayar() {
            var totalBelanja = parseFloat(totalBelanjaInput.value) || 0;
            var diskon = parseFloat(diskonInput.value) || 0;
            var totalBayar = totalBelanja - diskon;
            totalBayarInput.value = totalBayar.toFixed(2);
        }
    });


    document.addEventListener("DOMContentLoaded", function() {
        var totalBayarInput = document.getElementById("total_bayar");
        var pembayaranInput = document.getElementById("pembayaran");
        var utangInput = document.getElementById("utang");

        totalBayarInput.addEventListener("input", calculateUtang);
        pembayaranInput.addEventListener("input", calculateUtang);

        function calculateUtang() {
            var totalBayar = parseFloat(totalBayarInput.value) || 0;
            var pembayaran = parseFloat(pembayaranInput.value) || 0;
            var utang = Math.max(0, totalBayar - pembayaran); // Menghindari nilai negatif
            utangInput.value = utang.toFixed(2);
        }
    });
</script>
