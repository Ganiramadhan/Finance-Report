@extends('layouts.admin.app', ['title' => 'Tambah Produk'])

@section('content')
    <div class="section-header">
        <h1>Tambah Produk</h1>
    </div>
    <hr />

    <form action="{{ route('product.store') }}" method="POST">
        @csrf
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Nama Produk</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama Produk" required
                    value="{{ old('nama') }}">
                {{-- @error('nama')
                    <div class="alert alert-danger mt-2">{{ $message }}</div>
                @enderror --}}
            </div>

            <div class="col">
                <label class="form-label">Harga Beli</label>
                <input type="number" name="hrg_jual" class="form-control" placeholder="Harga Beli" required
                    value="{{ old('hrg_jual') }}">
            </div>
            <div class="col">
                <label class="form-label">Satuan</label>
                <select name="satuan" class="form-select" required>
                    <option value="">Pilih Satuan</option>
                    <option value="unit" {{ old('satuan') === 'unit' ? 'selected' : '' }}>Unit</option>
                    <option value="pcs" {{ old('satuan') === 'pcs' ? 'selected' : '' }}>Pcs</option>
                    <option value="box" {{ old('satuan') === 'box' ? 'selected' : '' }}>Box</option>
                    <option value="liter" {{ old('satuan') === 'liter' ? 'selected' : '' }}>Liter</option>
                    <!-- Anda dapat menambahkan lebih banyak opsi sesuai kebutuhan -->
                </select>
            </div>
        </div>
        <div class="row mb-3">
              <div class="col">
                <label class="form-label">Harga Jual</label>
                <input type="number" name="hrg_beli_satuan" class="form-control" placeholder="Harga Jual"
                    id="hrg_beli_satuan" required value="{{ old('hrg_beli_satuan') }}">
            </div>
            <div class="col">
                <label class="form-label">Jumlah Produk</label>
                <input type="number" name="qty" class="form-control" placeholder="Jumlah Produk" id="qty"
                    required value="{{ old('qty') }}">
            </div>
          
            <div class="col">
                <label class="form-label">Total Bayar</label>
                <input type="text" name="total" class="form-control" placeholder="Total Harga" id="total" readonly
                    value="{{ old('total') }}">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="d-grid">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Tambah</button>
                </div>
            </div>
        </div>
    </form>

    <script>
        $(document).ready(function() {
            // Cek apakah ada pesan kesalahan dalam variabel JavaScript
            var errorMessage = "{{ $errors->first('nama') }}";

            if (errorMessage) {
                // Tampilkan pesan kesalahan menggunakan Toastr
                toastr.error(errorMessage);
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            var qtyInput = document.getElementById("qty");
            var hargaBeliSatuanInput = document.getElementById("hrg_beli_satuan");
            var totalInput = document.getElementById("total");

            qtyInput.addEventListener("input", updateTotal);
            hargaBeliSatuanInput.addEventListener("input", updateTotal);

            function updateTotal() {
                var qty = parseFloat(qtyInput.value) || 0;
                var hargaBeliSatuan = parseFloat(hargaBeliSatuanInput.value) || 0;
                var total = qty * hargaBeliSatuan;
                totalInput.value = total.toFixed(2);
            }
        });
    </script>
@endsection
