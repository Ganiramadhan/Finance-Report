@extends('layouts.admin.app', ['title' => 'Edit Supplier'])

@section('content')
    <div class="section-header">
        <h1>Edit Supplier</h1>
    </div>
    <hr />
    <form action="{{ route('supplier.update', $supplier->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama" value="{{ $supplier->nama }}">
            </div>
            <div class="col mb-3">
                <label class="form-label">Utang</label>
                <input type="text" name="saldo_awal_utang" class="form-control" placeholder="Saldo Awal Utang"
                    value="{{ $supplier->saldo_awal_utang }}">
            </div>
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat"
                    value="{{ $supplier->alamat }}">
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                    value="{{ $supplier->no_telepon }}">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
@endsection
