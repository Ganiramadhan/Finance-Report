@extends('layouts.admin.app', ['title' => 'Tambah Supplier'])

@section('content')
    <div class="section-header">
        <h1>Tambah Supplier</h1>
    </div>
    <hr />
    <form action="{{ route('supplier.store') }}" method="POST">
        @csrf
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="nama" class="form-control" placeholder="Nama" required>
            </div>
            <div class="col">
                <input type="text" name="saldo_awal_utang" class="form-control" placeholder="Saldo Awal Utang" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"required>
            </div>

        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="alamat" class="form-control" placeholder="Alamat "required>
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
@endsection
