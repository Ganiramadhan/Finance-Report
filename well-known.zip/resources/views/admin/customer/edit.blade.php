@extends('layouts.admin.app', ['title' => 'Edit Customer'])

@section('content')
    <div class="section-header">
        <h1>Edit Customer</h1>
    </div>
    <hr />
    <form action="{{ route('customer.update', $customer->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama" value="{{ $customer->nama }}"
                    required>

            </div>
            <div class="col mb-3">
                <label class="form-label">Saldo Awal Piutang</label>
                <input type="number" name="saldo_awal_piutang" class="form-control" placeholder="Saldo Awal Piutang"
                    value="{{ $customer->saldo_awal_piutang }}" required>

            </div>
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat"
                    value="{{ $customer->alamat }}" required>
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                    value="{{ $customer->no_telepon }}" required>
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
@endsection
