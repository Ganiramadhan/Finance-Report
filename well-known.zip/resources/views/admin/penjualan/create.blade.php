@extends('layouts.admin.app', ['title' => 'Tambah Penjualan'])

@section('content')
    <div class="section-header">
        <h1>Tambah Penjualan</h1>
    </div>
    <hr />
    {{-- @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif --}}

    <form action="{{ route('penjualan.store') }}" method="POST">
        @csrf

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Customer</label>
                    <select class="form-control" id="customer_id" name="customer_id" required>
                        <option value="">Pilih Customer</option>
                        @foreach ($data_customer as $item)
                            <option value="{{ $item->id }}" data-saldo_awal_piutang="{{ $item->saldo_awal_piutang }}">
                                {{ $item->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Jenis Produk</label>
                    <select class="form-control" id="product_id" name="product_id" required>
                        <option value="">Pilih Jenis Produk</option>
                        @foreach ($data_product as $item)
                            <option value="{{ $item->id }}" data-harga="{{ $item->hrg_beli_satuan }}"
                                data-satuan="{{ $item->satuan }}">{{ $item->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <input type="hidden" name="hrg_beli_satuan" id="hrg_beli_satuan" class="form-control"
                    placeholder="hrg_beli_satuan" required readonly>
                <!-- Tambahkan input untuk satuan -->

                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="qty" id="qty" class="form-control" placeholder="Jumlah" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Satuan</label>
                    <input type="text" id="satuan" name="satuan" class="form-control" placeholder="Satuan" readonly>
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Harga</label>
                    <input type="text" name="total_harga" id="total_harga" class="form-control" placeholder="Total Harga"
                        readonly>
                </div>

                <div class="mb-3">
                    <label class="form-label">Metode Pembayaran</label>
                    <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                        <option value="">Metode Pembayaran</option>
                        @foreach ($data_metode_pembayaran as $item)
                            <option value="{{ $item->id }}">{{ $item->metode_pembayaran }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Belanja</label>
                    <input type="number" name="total_belanja" id="total_belanja" class="form-control"
                        placeholder="Total Belanja" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Diskon</label>
                    <input type="number" name="diskon" id="diskon" class="form-control" placeholder="Diskon" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Total Bayar</label>
                    <input type="number" name="total_bayar" id="total_bayar" class="form-control" placeholder="Total Bayar"
                        readonly>
                </div>

                <div class="mb-3">
                    <label class="form-label">Pembayaran</label>
                    <input type="number" name="pembayaran" id="pembayaran" class="form-control" placeholder="Pembayaran"
                        required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Piutang</label>
                    <input type="number" name="piutang" id="piutang" class="form-control" placeholder="Piutang" readonly>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control"
                        placeholder="Tanggal Transaksi" required>
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Nomor Faktur</label>
                    <input type="text" name="no_faktur" id="no_faktur" class="form-control"
                        placeholder="Nomor Faktur" required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="d-grid">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var productSelect = document.getElementById("product_id");
            var satuanInput = document.getElementById("satuan");
            var hargaBeliSatuanInput = document.getElementById("hrg_beli_satuan");
            var qtyInput = document.getElementById("qty");
            var totalHargaInput = document.getElementById("total_harga");
            var totalBelanjaInput = document.getElementById("total_belanja");
            var diskonInput = document.getElementById("diskon");
            var totalBayarInput = document.getElementById("total_bayar");
            var pembayaranInput = document.getElementById("pembayaran");
            var utangInput = document.getElementById("piutang");
            var saldoAwalPiutang = 0; // Variabel untuk menyimpan saldo awal piutang

            // Function to update the "Satuan" field based on the selected product
            function updateSatuan() {
                var selectedOption = productSelect.options[productSelect.selectedIndex];
                var satuan = selectedOption.getAttribute("data-satuan") || "";
                satuanInput.value = satuan;
                updateHargaBeliSatuan();
            }

            // Event listener for changes in the selected product
            productSelect.addEventListener("change", function() {
                updateSatuan();
            });

            qtyInput.addEventListener("input", function() {
                if (pembayaranInput.value === "") {
                    calculateTotalHarga();
                    calculateTotalBelanja();
                }
            });

            diskonInput.addEventListener("input", function() {
                calculateTotalBelanja();
            });

            pembayaranInput.addEventListener("input", function() {
                calculateUtang();
            });

            // Function to update harga beli satuan based on the selected product
            function updateHargaBeliSatuan() {
                var selectedOption = productSelect.options[productSelect.selectedIndex];
                var hargaBeli = parseFloat(selectedOption.getAttribute("data-harga")) || 0;
                hargaBeliSatuanInput.value = hargaBeli.toFixed(2);
                calculateTotalHarga();
            }

            // Function to update total harga
            function calculateTotalHarga() {
                var hargaBeliSatuan = parseFloat(hargaBeliSatuanInput.value) || 0;
                var qty = parseFloat(qtyInput.value) || 0;
                var totalHarga = hargaBeliSatuan * qty;
                totalHargaInput.value = totalHarga.toFixed(2);
            }

            // Function to calculate total belanja
            function calculateTotalBelanja() {
                var totalHarga = parseFloat(totalHargaInput.value) || 0;
                var diskon = parseFloat(diskonInput.value) || 0;
                var totalBelanja = totalHarga - diskon;
                totalBelanjaInput.value = totalBelanja.toFixed(2);
                calculateTotalBayar();
            }

            // Function to calculate total bayar
            function calculateTotalBayar() {
                var totalBelanja = parseFloat(totalBelanjaInput.value) || 0;
                totalBayarInput.value = totalBelanja.toFixed(2);
                calculateUtang();
            }

            // Function to calculate utang
            function calculateUtang() {
                var totalBayar = parseFloat(totalBayarInput.value) || 0;
                var pembayaran = parseFloat(pembayaranInput.value) || 0;
                var utang = totalBayar - pembayaran + saldoAwalPiutang;
                utangInput.value = utang.toFixed(2);
            }

            // Call the functions to set the initial values
            updateSatuan();

            var customerSelect = document.getElementById("customer_id");
            var saldoAwalPiutangInput = document.getElementById("piutang");

            // Event listener for changes in the selected customer
            customerSelect.addEventListener("change", function() {
                var selectedOption = customerSelect.options[customerSelect.selectedIndex];
                saldoAwalPiutang = parseFloat(selectedOption.getAttribute("data-saldo_awal_piutang")) || 0;
                calculateUtang(); // Re-calculate utang saat customer berubah
            });
        });
    </script>
@endsection
