@extends('layouts.app')

@section('body')
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="mb-0">Dashboard User</h5>
        <br>
    </div>
    <hr />
@endsection
