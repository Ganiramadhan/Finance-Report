@extends('layouts.app')

@section('body')
    <h4 class="mb-0">Tambah Data Supplier</h4>
    <hr />
    <form action="{{ route('supplier.store') }}" method="POST">
        @csrf
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="nama" class="form-control" placeholder="Nama">
            </div>
            <div class="col">
                <input type="text" name="saldo_awal_utang" class="form-control" placeholder="Saldo Awal Utang">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="number" name="no_telepon" class="form-control" placeholder="Nomor Telepon">
            </div>

        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="alamat" class="form-control" placeholder="Alamat ">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
@endsection
