@extends('layouts.app')

@section('body')
    <h5 class="mb-0">Edit Customer</h5>
    <hr />
    <form action="{{ route('customer.update', $customer->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama" value="{{ $customer->nama }}">

            </div>
            <div class="col mb-3">
                <label class="form-label">Saldo Awal Piutang</label>
                <input type="text" name="saldo_awal_piutang" class="form-control" placeholder="Saldo Awal Piutang"
                    value="{{ $customer->saldo_awal_piutang }}">

            </div>
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat"
                    value="{{ $customer->alamat }}">
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                    value="{{ $customer->no_telepon }}">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
@endsection
