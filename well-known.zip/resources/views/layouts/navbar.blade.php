<style>
    .nav-item.active {
        background-color: #007bff;
        color: #fff;
    }
</style>

{{-- <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/admin">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('product.index') }}">Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('customer.index') }}">Customer</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('supplier.index') }}">Supplier</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('transaksi.index') }}">Transaksi</a>
                </li>
                <li class="nav-item">
                    <form action="/logout" method="post">
                        @csrf
                        <button type="submit" class="btn btn-primary">Logout</button>
                    </form>
            </ul>
        </div>
    </div>
</nav>
 --}}

@if (auth()->user()->role_id == 1)
    <!-- Navbar admin -->
    @include('layouts.admin-navbar')
@else
    <!-- Navbar pengguna biasa -->
    @include('layouts.user-navbar')
@endif






<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menambahkan event click ke setiap item navbar
        $('.nav-item').click(function() {
            // Menghapus kelas "active" dari semua item navbar
            $('.nav-item').removeClass('active');
            // Menambahkan kelas "active" ke item yang diklik
            $(this).addClass('active');
        });
    });
</script>
