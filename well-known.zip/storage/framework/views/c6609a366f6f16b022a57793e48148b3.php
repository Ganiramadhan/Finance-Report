

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Edit Supplier</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('supplier.update', $supplier->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($supplier->nama); ?>">
            </div>
            <div class="col mb-3">
                <label class="form-label">Utang</label>
                <input type="text" name="saldo_awal_utang" class="form-control" placeholder="Saldo Awal Utang"
                    value="<?php echo e($supplier->saldo_awal_utang); ?>">
            </div>
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat"
                    value="<?php echo e($supplier->alamat); ?>">
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                    value="<?php echo e($supplier->no_telepon); ?>">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Edit Supplier'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/supplier/edit.blade.php ENDPATH**/ ?>