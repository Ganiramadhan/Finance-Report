

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Edit Kategori Pengeluaran</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('kategori_pengeluaran.update', $kategori_pengeluaran->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama_kategori" class="form-control" placeholder="Nama"
                    value="<?php echo e($kategori_pengeluaran->nama_kategori); ?>">
            </div>
            <div class="row">
                <div class="d-grid">
                    <button class="btn btn-success">Update</button>
                </div>
            </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Edit Kategori Pengeluaran'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/kategori_pengeluaran/edit.blade.php ENDPATH**/ ?>