

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Tambah Kategori Pengeluaran</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('kategori_pengeluaran.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="nama_kategori" class="form-control" placeholder="Kategori Pengeluaran">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Kategori Pengeluaran'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/kategori_pengeluaran/create.blade.php ENDPATH**/ ?>