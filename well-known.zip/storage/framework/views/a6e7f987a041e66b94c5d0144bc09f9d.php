

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Tambah Utang</h1>
    </div>
    <hr />
    
    <form action="<?php echo e(route('utang.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <div class="form-group">
                    <label for="supplier_id">Nama Supplier</label>
                    <select class="form-control" id="supplier_id" name="supplier_id" required>
                        <option value="">Pilih Nama Supplier</option>
                        <?php $__currentLoopData = $data_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" data-saldo="<?php echo e($item->saldo_awal_utang); ?>">
                                <?php echo e($item->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="saldo_awal_utang">Saldo Awal Utang</label>
                    <input type="text" name="saldo_awal_utang" id="saldo_awal_utang" class="form-control"
                        placeholder="Saldo Awal Utang" required readonly>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="pembayaran">Jumlah Pembayaran</label>
                    <input type="text" name="pembayaran" id="pembayaran" class="form-control"
                        placeholder="Jumlah Pembayaran" required>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="sisa_utang">Sisa Piutang</label>
                    <input type="text" name="sisa_utang" id="sisa_utang" class="form-control" placeholder="Sisa Piutang"
                        required readonly>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="metode_pembayaran_id">Metode Pembayaran</label>
                    <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                        <option value="">Pilih Metode Pembayaran</option>
                        <?php $__currentLoopData = $data_metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->metode_pembayaran); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-8">
                <div class="form-group">
                    <label for="keterangan">Keterangan</label>
                    <input type="text" name="keterangan" id="keterangan" class="form-control" placeholder="Keterangan"
                        required>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="tanggal">Tanggal Transaksi</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control" placeholder="Tanggal Transaksi"
                        required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <button class="btn btn-primary" type="submit">Submit</button>
            </div>
        </div>
    </form>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var saldoAwalUtangInput = document.getElementById("saldo_awal_utang");
            var pembayaranInput = document.getElementById("pembayaran");
            var keteranganInput = document.getElementById("keterangan");
            var sisaUtangInput = document.getElementById("sisa_utang");

            pembayaranInput.addEventListener("input", function() {
                var saldoAwalUtang = parseFloat(saldoAwalUtangInput.value) || 0;
                var pembayaran = parseFloat(pembayaranInput.value) || 0;
                var sisaUtang = saldoAwalUtang - pembayaran;

                sisaUtang = Math.max(0, sisaUtang);

                if (sisaUtang === 0) {
                    keteranganInput.value = "Lunas";
                } else {
                    keteranganInput.value = "Belum Lunas";
                }

                sisaUtangInput.value = sisaUtang.toFixed(2);
            });

            var supplierSelect = document.getElementById("supplier_id");
            supplierSelect.addEventListener("change", function() {
                var selectedOption = supplierSelect.options[supplierSelect.selectedIndex];
                var selectedSupplierSaldo = selectedOption.getAttribute("data-saldo");
                saldoAwalUtangInput.value = selectedSupplierSaldo;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Utang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/utang/create.blade.php ENDPATH**/ ?>