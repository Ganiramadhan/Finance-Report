

<?php $__env->startSection('body'); ?>
    <h5 class="mb-0">Detail Transaksi</h5>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nama Customer</label>
            <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($transaksi->customer->nama); ?>"
                readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jumlah</label>
            <input type="text" name="jumlah" class="form-control" placeholder="Jumlah" value="<?php echo e($transaksi->jumlah); ?>"
                readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Harga</label>
            <input type="text" name="harga" class="form-control" placeholder="Harga" value="<?php echo e($transaksi->harga); ?>"
                readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Total</label>
            <input type="text" name="total" class="form-control" placeholder="Harga" value="<?php echo e($transaksi->total); ?>"
                readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nomor Telepon</label>
            <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                value="<?php echo e($transaksi->customer->no_telepon); ?>" readonly>
        </div>

    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Created At</label>
            <input type="text" name="created_at" class="form-control" placeholder="Created At"
                value="<?php echo e($transaksi->created_at); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Updated At</label>
            <input type="text" name="updated_at" class="form-control" placeholder="Updated At"
                value="<?php echo e($transaksi->updated_at); ?>" readonly>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/transaksi/show.blade.php ENDPATH**/ ?>