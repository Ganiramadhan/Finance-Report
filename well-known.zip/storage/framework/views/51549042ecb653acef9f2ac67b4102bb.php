

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Detail Customer</h1>
    </div>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($customer->nama); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Saldo Awal Piutang</label>
            <input type="text" name="nama" class="form-control" placeholder="Nama"
                value="<?php echo e('Rp ' . number_format($customer->saldo_awal_piutang, 0, ',', '.')); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Nomor Telepon</label>
            <input type="text" name="no_telepon" class="form-control" placeholder="Alamat"
                value="<?php echo e($customer->no_telepon); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Alamat</label>
            <input type="text" name="alamat" class="form-control" placeholder="Nomor Telepon"
                value="<?php echo e($customer->alamat); ?>" readonly>
        </div>

    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Created At</label>
            <input type="text" name="created_at" class="form-control" placeholder="Created At"
                value="<?php echo e($customer->created_at); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Updated At</label>
            <input type="text" name="updated_at" class="form-control" placeholder="Updated At"
                value="<?php echo e($customer->updated_at); ?>" readonly>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Detail Customer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/customer/show.blade.php ENDPATH**/ ?>