

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Data Akun Bank</h1>
    </div>
    

    <hr />
    
            <div class="table-responsive">

    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Jenis Rekening</th>
                <th>Saldo Rekening</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if($metode_pembayaran->count() > 0): ?>
                <?php $__currentLoopData = $metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($row->metode_pembayaran); ?></td>
                        <td class="align-middle"><?php echo e('Rp ' . number_format($row->saldo, 0, ',', '.')); ?></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Kategori pengeluaran not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Rekening'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/metode_pembayaran/index.blade.php ENDPATH**/ ?>