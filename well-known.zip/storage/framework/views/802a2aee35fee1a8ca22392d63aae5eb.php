

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Edit Produk</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('product.update', $product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Nama Produk</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama Produk"
                    value="<?php echo e(old('nama', $product->nama)); ?>" required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2"><?php echo e($message); ?> </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Satuan</label>
                <select name="satuan" class="form-select" required>
                    <option value="unit" <?php if($product->satuan == 'unit'): ?> selected <?php endif; ?>>Unit</option>
                    <option value="pcs" <?php if($product->satuan == 'pcs'): ?> selected <?php endif; ?>>Pcs</option>
                    <option value="box" <?php if($product->satuan == 'box'): ?> selected <?php endif; ?>>Box</option>
                    <option value="liter" <?php if($product->satuan == 'liter'): ?> selected <?php endif; ?>>Liter</option>
                    <!-- Anda dapat menambahkan lebih banyak opsi sesuai kebutuhan -->
                </select>
            </div>


        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Jumlah Produk</label>
                <input type="number" name="qty" id="qty" class="form-control" placeholder="Jumlah Produk"
                    value="<?php echo e($product->qty); ?>" required>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Harga Beli Satuan</label>
                <input type="number" name="hrg_beli_satuan" id="hrg_beli_satuan" class="form-control"
                    placeholder="Harga Beli Satuan" value="<?php echo e($product->hrg_beli_satuan); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Total Produk</label>
                <input type="number" name="total" id="total_produk" class="form-control" placeholder="Total Produk"
                    value="<?php echo e($product->total); ?>" required readonly>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="d-grid">
                    <button class="btn btn-success">Update</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Ambil elemen yang dibutuhkan
        var qtyInput = document.getElementById('qty');
        var hargaBeliSatuanInput = document.getElementById('hrg_beli_satuan');
        var totalInput = document.getElementById('total_produk');

        // Tambahkan event listener ketika qtyInput atau hargaBeliSatuanInput berubah
        qtyInput.addEventListener('input', updateTotal);
        hargaBeliSatuanInput.addEventListener('input', updateTotal);

        // Fungsi untuk mengupdate total
        function updateTotal() {
            var qty = parseFloat(qtyInput.value) || 0;
            var hargaBeliSatuan = parseFloat(hargaBeliSatuanInput.value) || 0;
            var total = qty * hargaBeliSatuan;
            totalInput.value = total.toFixed(2); // Membulatkan total menjadi dua angka desimal
        }

        // Panggil fungsi updateTotal saat halaman dimuat
        updateTotal();
    });
</script>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Edit Produk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>