

<?php $__env->startSection('body'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="mb-0">Data Konversi Kas</h5>
        <a href="<?php echo e(route('konversi_kas.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus"></i> Tambah Data
        </a>
    </div>
    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>

    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Kode Konversi Kas</th>
                <th>Rekening Asal</th>
                <th>Rekening Tujuan</th>
                <th>Keterangan</th>
                <th>Jumlah</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if($konversi_kas->count() > 0): ?>
                <?php $__currentLoopData = $konversi_kas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($row->kd_konversi_kas); ?></td>
                        <td class="align-middle"><?php echo e($row->metode_pembayaran->metode_pembayaran); ?></td>
                        <td class="align-middle"><?php echo e($row->metode_pembayaran->metode_pembayaran); ?></td>
                        <td class="align-middle"><?php echo e($row->keterangan); ?></td>
                        <td class="align-middle"><?php echo e('Rp ' . number_format($row->jumlah, 0, ',', '.')); ?></td>
                        <td class="align-middle"><?php echo e($row->tanggal); ?></td>
                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('penjualan.edit', $row->id)); ?>" type="button" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('penjualan.destroy', $row->id)); ?>" method="POST"
                                    class="btn btn-danger p-0"
                                    onsubmit="return confirm('Apakah anda ingin menghapus data ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger m-0">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="6">Data tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/konversi_kas/index.blade.php ENDPATH**/ ?>