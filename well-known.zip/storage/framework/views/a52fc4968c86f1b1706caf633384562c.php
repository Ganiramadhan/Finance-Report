<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
          <img src="../../../img/mki.png" alt="icon" class="loading-icon" width="50" height="50">  <a href="#">Laporan Keuangan</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <img src="../../../img/mki.png" alt="icon" class="loading-icon" width="50" height="50">
        </div>
        <ul class="sidebar-menu">
            
            <li class="nav-item ">
                <a href="/admin" class="nav-link"><i class="fas fa-home"></i><span>Dashboard</span></a>

            </li>
            <li class="menu-header">MENU</li>

            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i>
                    <span>Data Master</span></a>
                <ul class="dropdown-menu">
                    <li> <a class="nav-link" href="<?php echo e(route('product.index')); ?>"><i class="fas fa-box"></i> Product</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('customer.index')); ?>"><i class="fas fa-users"></i>
                            Customer</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('supplier.index')); ?>"><i class="fas fa-truck"></i>
                            Supplier</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i>
                    <span>Transaksi</span></a>
                <ul class="dropdown-menu">
                    <li> <a class="nav-link" href="<?php echo e(route('penjualan.index')); ?>"><i class="fas fa-shopping-cart"></i>
                            Penjualan</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('pembayaran.index')); ?>"><i class="fas fa-money-bill"></i>
                            Pembayaran</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('pembelian.index')); ?>"><i
                                class="fas fa-shopping-basket"></i> Pembelian</a></li>
                    <li> <a class="nav-link" href="<?php echo e(route('transaksi.index')); ?>"><i class="fas fa-exchange-alt"></i>
                            Transaksi Lainnya</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('utang.index')); ?>"><i class="fas fa-money-check"></i>
                    <span>Utang</span></a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('piutang.index')); ?>"><i class="fas fa-money-check-alt"></i>
                    <span>Piutang </span> </a>
            </li>
            <li class="menu-header">Lainnya</li>

            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-cog"></i>
                    <span>Data Lainnya</span></a>

                <ul class="dropdown-menu">
                    <li> <a class="nav-link" href="<?php echo e(route('metode_pembayaran.index')); ?>"><i
                                class="fas fa-university"></i> Akun Bank</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('jenis_transaksi.index')); ?>"><i
                                class="fas fa-list-alt"></i> Jenis Transaksi</a>
                    </li>
                    <li> <a class="nav-link" href="<?php echo e(route('kategori_pengeluaran.index')); ?>"><i
                                class="fas fa-money-bill-wave"></i> Jenis Pengeluaran</a>
                    </li>
                </ul>
            </li>
        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">

            <form action="/logout" method="post" class="m-2">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary btn-lg btn-block"> <i class="fas fa-sign-out-alt"></i>

                    Logout</button>
            </form>
        </div>


    </aside>
</div>
<?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/layouts/admin/partials/sidebar.blade.php ENDPATH**/ ?>