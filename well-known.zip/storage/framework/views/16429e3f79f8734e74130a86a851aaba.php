

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Data Utang</h1>
    </div>
    <div class="row">
        <div class="col-6">
            <div class="search-element">
                <input class="form-control" placeholder="Cari Data Utang" aria-label="Search" data-width="250" name="search"
                    id="search">
            </div>
        </div>
        <div class="col-6 text-right">
            <h5 class="mb-0"></h5>
            <a href="<?php echo e(route('utang.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i> Tambah Data
            </a>
        </div>
    </div>

    <hr />
    
    <div class="table-responsive">

    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead class="table-primary">
            <tr>
                <th>Nomor</th>
                <th>Nama Supplier</th>
                
                <th>Pembayaran</th>
                <th>Sisa utang</th>
                <th>Keterangan</th>
                <th>Metode Pembayaran</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="utang-list">
            <?php if($utangs->count() > 0): ?>
                <?php $__currentLoopData = $utangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($row->id); ?></td>
                        <td class="align-middle"><?php echo e($row->supplier->nama); ?></td>
                        
                        <td class="align-middle"><?php echo e('Rp ' . number_format($row->pembayaran, 0, ',', '.')); ?></td>
                        <td class="align-middle"><?php echo e('Rp ' . number_format($row->sisa_utang, 0, ',', '.')); ?></td>
                        <td class="align-middle"><?php echo e($row->keterangan); ?></td>
                        <td class="align-middle"><?php echo e($row->metode_pembayaran->metode_pembayaran); ?></td>
                        <td class="align-middle"><?php echo e($row->tanggal); ?></td>
                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                
                                <a href="<?php echo e(route('utang.edit', $row->id)); ?>" type="button" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('utang.destroy', $row->id)); ?>" method="POST"
                                    class="btn btn-danger p-0"
                                    onsubmit="return confirm('Apakah anda ingin menghapus data ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger m-0">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="9">Data Utang tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div id="pagination" class="d-flex justify-content-center mt-3">
        <ul class="pagination">
            <li class="page-item <?php echo e($utangs->previousPageUrl() ? '' : 'disabled'); ?>">
                <a class="page-link" href="<?php echo e($utangs->previousPageUrl()); ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for($i = 1; $i <= $utangs->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $utangs->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($utangs->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo e($utangs->nextPageUrl() ? '' : 'disabled'); ?>">
                <a class="page-link" href="<?php echo e($utangs->nextPageUrl()); ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </div>
   </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            var currentPage = <?php echo e($utangs->currentPage()); ?>;

            $('#search').on('keyup', function() {
                var query = $(this).val();
                $.ajax({
                    url: "<?php echo e(route('utang.search')); ?>",
                    type: "GET",
                    data: {
                        'query': query,
                        'page': currentPage
                    },
                    success: function(data) {
                        $('#utang-list').html(data.data);
                        currentPage = 1;
                        updateTableNumber();
                        updatePaginationButtons();
                    }
                });
            });

            $(document).on('click', '.pagination a', function(event) {
                event.preventDefault();
                var page = $(this).attr('href').split('page=')[1];
                if (page === undefined) {
                    return;
                }
                currentPage = parseInt(page);
                $('.pagination li').removeClass('active');
                $(this).closest('li').addClass('active');
                $.ajax({
                    url: "<?php echo e(route('utang.search')); ?>",
                    type: "GET",
                    data: {
                        'query': $('#search').val(),
                        'page': page
                    },
                    success: function(data) {
                        $('#utang-list').html(data.data);
                        updateTableNumber();
                        updatePaginationButtons();
                    }
                });
            });

            function updatePaginationButtons() {
                $('.pagination li:first-child').toggleClass('disabled', currentPage === 1);
                $('.pagination li:last-child').toggleClass('disabled', currentPage ===
                    <?php echo e($utangs->lastPage()); ?>);
            }

            updatePaginationButtons();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Data Utang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/utang/index.blade.php ENDPATH**/ ?>