

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Tambah Customer</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('customer.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="nama" class="form-control" placeholder="Nama" required>
            </div>
            <div class="col">
                <input type="number" name="saldo_awal_piutang" class="form-control" placeholder="Saldo Awal Piutang"
                    required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="number" name="no_telepon" class="form-control" placeholder="Nomor Telepon" required>
            </div>

        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="alamat" class="form-control" placeholder="Alamat " required>
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Customer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/customer/create.blade.php ENDPATH**/ ?>