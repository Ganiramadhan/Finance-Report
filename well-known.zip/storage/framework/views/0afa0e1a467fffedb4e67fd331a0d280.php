

<?php $__env->startSection('body'); ?>
    <h5 class="mb-0">Edit Transaksi</h5>
    <hr />
    <form action="<?php echo e(route('transaksi.update', $transaksi->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">

            <div class="col mb-3">
                <select class="form-control" id="customer_id" name="customer_id">
                    <option value=""></option>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == $transaksi->customer_id): ?> selected <?php endif; ?>>
                            <?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>


            <div class="col">
                <select class="form-control" id="product_id" name="product_id">
                    <option value="">Product</option>
                    <?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" data-hrg-jual="<?php echo e($item->hrg_jual); ?>"
                            <?php if($item->id == $transaksi->product_id): ?> selected <?php endif; ?>>
                            <?php echo e($item->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col">
                <input type="text" name="hrg_jual" id="hrg_jual" class="form-control" placeholder="Harga" readonly>
            </div>

            <input type="hidden" name="hrg_jual_hidden" id="hrg_jual_hidden">



            <div class="row">
                <div class="col mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="text" name="jumlah" class="form-control" placeholder="Jumlah"
                        value="<?php echo e($transaksi->jumlah); ?>">

                </div>

                <div class="col mb-3">
                    <label class="form-label">Total</label>
                    <input type="text" name="total" class="form-control" placeholder="Total"
                        value="<?php echo e($transaksi->total); ?>">
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<script>
    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');

        // Fungsi untuk mengatur harga berdasarkan pilihan produk
        function setHarga() {
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var harga = selectedOption.getAttribute('data-hrg-jual');
            hargaInput.value = harga;
        }

        // Panggil fungsi setHarga saat dokumen dimuat dan saat pilihan produk berubah
        setHarga();
        productSelect.addEventListener('change', setHarga);
    });


    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');
        var jumlahInput = document.getElementById('jumlah');
        var totalHargaInput = document.getElementById('total');

        // Fungsi untuk menghitung total harga berdasarkan harga dan jumlah
        function hitungTotalHarga() {
            var harga = parseFloat(hargaInput.value);
            var jumlah = parseInt(jumlahInput.value);
            var totalHarga = harga * jumlah;
            totalHargaInput.value = totalHarga.toFixed(2); // Mengatur jumlah desimal
        }

        // Panggil fungsi hitungTotalHarga saat dokumen dimuat dan saat input harga atau jumlah berubah
        setHarga();
        hitungTotalHarga();
        productSelect.addEventListener('change', function() {
            setHarga();
            hitungTotalHarga();
        });
        jumlahInput.addEventListener('input', hitungTotalHarga);
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/transaksi/edit.blade.php ENDPATH**/ ?>