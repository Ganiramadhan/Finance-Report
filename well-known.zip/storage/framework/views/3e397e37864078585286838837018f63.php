

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Tambah Pembelian</h1>
    </div>
    <hr />
    
    <form action="<?php echo e(route('pembelian.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Kode Transaksi</label>
                    <input type="text" name="kd_transaksi" id="kd_transaksi" class="form-control"
                        placeholder="Kode Transaksi" required value="<?php echo e(old('kd_transaksi')); ?>">

                    <?php $__errorArgs = ['kd_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jenis Produk</label>
                    <select class="form-control" id="product_id" name="product_id" required>
                        <option value="">Pilih Jenis Produk</option>
                        <?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" data-satuan="<?php echo e($item->satuan); ?>"
                                data-harga="<?php echo e($item->hrg_jual); ?>"
                                <?php echo e(old('product_id') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="hrg_beli_satuan" id="hrg_beli_satuan" class="form-control"
                    placeholder="hrg_beli_satuan" required readonly value="<?php echo e(old('hrg_beli_satuan')); ?>">

                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="qty" id="qty" class="form-control" placeholder="Jumlah" required
                        value="<?php echo e(old('qty')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Satuan</label>
                    <input type="text" id="satuan" name="satuan" class="form-control" placeholder="Satuan" readonly
                        value="<?php echo e(old('satuan')); ?>">
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Harga</label>
                    <input type="text" name="total_harga" id="total_harga" class="form-control" placeholder="Total Harga"
                        readonly value="<?php echo e(old('hrg_jual')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Metode Pembayaran</label>
                    <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                        <option value="">Metode Pembayaran</option>
                        <?php $__currentLoopData = $data_metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"
                                <?php echo e(old('metode_pembayaran_id') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->metode_pembayaran); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Supplier</label>
                    <select class="form-control" id="supplier_id" name="supplier_id" required>
                        <option value="">Supplier</option>
                        <?php $__currentLoopData = $data_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('supplier_id') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Total Belanja</label>
                    <input type="number" name="total_belanja" id="total_belanja" class="form-control"
                        placeholder="Total Belanja" required value="<?php echo e(old('total_belanja')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Diskon</label>
                    <input type="number" name="diskon" id="diskon" class="form-control" placeholder="Diskon" required
                        value="<?php echo e(old('diskon')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Total Bayar</label>
                    <input type="number" name="total_bayar" id="total_bayar" class="form-control" placeholder="Total Bayar"
                        required value="<?php echo e(old('total_bayar')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Pembayaran</label>
                    <input type="number" name="pembayaran" id="pembayaran" class="form-control" placeholder="Pembayaran"
                        required value="<?php echo e(old('pembayaran')); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Utang</label>
                    <input type="string" name="utang" id="utang" class="form-control" placeholder="Utang"
                        required value="<?php echo e(old('utang')); ?>">
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="keterangan" id="keterangan" class="form-control"
                        placeholder="Keterangan" required value="<?php echo e(old('keterangan')); ?>">
                </div>
            </div>

            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control"
                        placeholder="Tanggal Transaksi" required value="<?php echo e(old('tanggal')); ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="d-grid">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>

    <script>
        // ... Bagian JavaScript lainnya yang sudah Anda miliki tetap sama seperti sebelumnya
    </script>
<?php $__env->stopSection(); ?>


<script>
    function setKodePembelian() {
        document.getElementById('kd_transaksi').value = 'TPP-';
    }

    // Panggil fungsi setKodePembelian saat halaman dimuat
    window.onload = setKodePembelian;


    document.addEventListener("DOMContentLoaded", function() {
        var productSelect = document.getElementById("product_id");
        var satuanInput = document.getElementById("satuan");

        // Function to update the "Satuan" field based on the selected product
        function updateSatuan() {
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var satuan = selectedOption.getAttribute("data-satuan") || "";
            satuanInput.value = satuan;
        }

        // Event listener for changes in the selected product
        productSelect.addEventListener("change", function() {
            updateSatuan();
        });

        // Call the function to set the initial value
        updateSatuan();
    });

document.addEventListener("DOMContentLoaded", function() {
    var productSelect = document.getElementById("product_id");
    var qtyInput = document.getElementById("qty");
    var totalHargaInput = document.getElementById("total_harga");

    productSelect.addEventListener("change", function() {
        var selectedOption = productSelect.options[productSelect.selectedIndex];
        var selectedHarga = parseFloat(selectedOption.getAttribute("data-harga")) || 0;
        totalHargaInput.value = selectedHarga.toFixed(2);
    });

    qtyInput.addEventListener("input", function() {
        calculateTotalHarga();
    });

    function calculateTotalHarga() {
        var selectedOption = productSelect.options[productSelect.selectedIndex];
        var selectedHarga = parseFloat(selectedOption.getAttribute("data-harga")) || 0;
        totalHargaInput.value = selectedHarga.toFixed(2);
    }
});




    document.addEventListener("DOMContentLoaded", function() {
        var totalBelanjaInput = document.getElementById("total_belanja");
        var diskonInput = document.getElementById("diskon");
        var totalBayarInput = document.getElementById("total_bayar");

        totalBelanjaInput.addEventListener("input", calculateTotalBayar);
        diskonInput.addEventListener("input", calculateTotalBayar);

        function calculateTotalBayar() {
            var totalBelanja = parseFloat(totalBelanjaInput.value) || 0;
            var diskon = parseFloat(diskonInput.value) || 0;
            var totalBayar = totalBelanja - diskon;
            totalBayarInput.value = totalBayar.toFixed(2);
        }
    });


    document.addEventListener("DOMContentLoaded", function() {
        var totalBayarInput = document.getElementById("total_bayar");
        var pembayaranInput = document.getElementById("pembayaran");
        var utangInput = document.getElementById("utang");

        totalBayarInput.addEventListener("input", calculateUtang);
        pembayaranInput.addEventListener("input", calculateUtang);

        function calculateUtang() {
            var totalBayar = parseFloat(totalBayarInput.value) || 0;
            var pembayaran = parseFloat(pembayaranInput.value) || 0;
            var utang = Math.max(0, totalBayar - pembayaran); // Menghindari nilai negatif
            utangInput.value = utang.toFixed(2);
        }
    });
</script>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Pembelian'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/pembelian/create.blade.php ENDPATH**/ ?>