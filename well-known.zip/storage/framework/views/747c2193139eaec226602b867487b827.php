

<?php $__env->startSection('body'); ?>
    <h5 class="mb-0">Tambah Transaksi</h5>
    <hr />
    <form action="<?php echo e(route('transaksi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            
            <div class="col">
                <select class="form-control" id="customer_id" name="customer_id">
                    <option value="">Nama Customer</option>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>



            <div class="col">
                <select class="form-control" id="product_id" name="product_id">
                    <option value="">Product</option>
                    <?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" data-hrg-jual="<?php echo e($item->hrg_jual); ?>"><?php echo e($item->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>



            <div class="col">
                <input type="text" name="hrg_jual" id="hrg_jual" class="form-control" placeholder="Harga" readonly>
            </div>

            



            <div class="col">
                <input type="number" name="jumlah" id="jumlah" class="form-control" placeholder="Jumlah" min="1"
                    value="1">
            </div>

        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="total" id="total" class="form-control" placeholder="Total Harga" readonly>
            </div>
            

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/transaksi/create.blade.php ENDPATH**/ ?>