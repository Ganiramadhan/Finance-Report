<style>
    .nav-item.active {
        background-color: #007bff;
        color: #fff;
    }
</style>



<?php if(auth()->user()->role_id == 1): ?>
    <!-- Navbar admin -->
    <?php echo $__env->make('layouts.admin-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <!-- Navbar pengguna biasa -->
    <?php echo $__env->make('layouts.user-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>






<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menambahkan event click ke setiap item navbar
        $('.nav-item').click(function() {
            // Menghapus kelas "active" dari semua item navbar
            $('.nav-item').removeClass('active');
            // Menambahkan kelas "active" ke item yang diklik
            $(this).addClass('active');
        });
    });
</script>
<?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>