

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Detail Pembayaran</h1>
    </div>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Jenis Pengeluaran</label>
            <input type="text" name="nama" class="form-control" placeholder="Jenis Pengeluaran"
                value="<?php echo e($pembayaran->kategori_pengeluaran->nama_kategori); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jumlah</label>
            <input type="text" name="penerima" class="form-control" placeholder="Penerima"
                value="<?php echo e($pembayaran->penerima); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Keterangan</label>
            <input type="text" name="keterangan" class="form-control" placeholder="keterangan"
                value="<?php echo e($pembayaran->keterangan); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jumlah Pembayaran</label>
            <input type="text" name="jml_pembayaran" class="form-control" placeholder="Harga"
                value="<?php echo e('Rp ' . number_format($pembayaran->jml_pembayaran, 0, ',', '.')); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Metode Pembayaran</label>
            <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                value="<?php echo e($pembayaran->metode_pembayaran->metode_pembayaran); ?>" readonly>
        </div>

    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Tanggal Transaksi</label>
            <input type="date" name="tanggal" class="form-control" placeholder="Tanggal Transaksi"
                value="<?php echo e($pembayaran->tanggal); ?>" readonly>
        </div>

    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Created At</label>
            <input type="text" name="created_at" class="form-control" placeholder="Created At"
                value="<?php echo e($pembayaran->created_at); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Updated At</label>
            <input type="text" name="updated_at" class="form-control" placeholder="Updated At"
                value="<?php echo e($pembayaran->updated_at); ?>" readonly>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Detail Pembayaran'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/pembayaran/show.blade.php ENDPATH**/ ?>