

<?php $__env->startSection('body'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="mb-0">Data Transaksi dan Customer</h5>
        <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-primary">Transaksi</a>
    </div>
    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Produk</th>
                <th>Harga</th>
                
                <th>No Telepon</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if($transaksi->count() > 0): ?>
                <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($row->customer->nama); ?></td>
                        <td class="align-middle"><?php echo e($row->product->nama); ?></td>
                        <td class="align-middle"><?php echo e($row->product->hrg_jual); ?></td>
                        
                        <td class="align-middle"><?php echo e($row->customer->no_telepon); ?></td>
                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('transaksi.show', $row->id)); ?>" type="button"
                                    class="btn btn-secondary">Detail</a>
                                <a href="<?php echo e(route('transaksi.edit', $row->id)); ?>" type="button"
                                    class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('transaksi.destroy', $row->id)); ?>" method="POST"
                                    onsubmit="return confirm('Apakah Anda yakin ingin menghapus data?')"
                                    class="btn btn-danger p-0">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger m-0">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="6">Data tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/transaksi/index.blade.php ENDPATH**/ ?>