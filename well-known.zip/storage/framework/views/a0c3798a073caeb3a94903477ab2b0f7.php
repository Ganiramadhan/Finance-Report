

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1> Tambah Pembayaran</h1>
    </div>
    <hr />
    

    <?php if($errors->has('kd_pembayaran')): ?>
        <div class="alert alert-danger">
            Kode Pembayaran sudah digunakan.
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="kd_pembayaran" id="kd_pembayaran" class="form-control" placeholder="Kode Pembayaran"
                    required value="<?php echo e(old('kd_pembayaran')); ?>">
            </div>
            <div class="col">
                <div class="form-group">
                    <select class="form-control" id="kategori_pengeluaran_id" name="kategori_pengeluaran_id" required>
                        <option value="">Jenis Pengeluaran</option>
                        <?php $__currentLoopData = $data_kategori_pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"
                                <?php echo e(old('kategori_pengeluaran_id') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <input type="text" name="penerima" id="penerima" class="form-control" placeholder="Penerima" required
                    value="<?php echo e(old('penerima')); ?>">
            </div>

            <div class="col">
                <input type="string" name="jml_pembayaran" id="jml_pembayaran" class="form-control"
                    placeholder="Jumlah Pembayaran" required value="<?php echo e(old('jml_pembayaran')); ?>">
            </div>

            <div class="col">
                <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                    <option value="">Metode Pembayaran</option>
                    <?php $__currentLoopData = $data_metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"
                            <?php echo e(old('metode_pembayaran_id') == $item->id ? 'selected' : ''); ?>>
                            <?php echo e($item->metode_pembayaran); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>
        <div class="row mb-3">
            <div class="col-8">
                <input type="text" name="keterangan" id="keterangan" class="form-control" placeholder="Keterangan"
                    required value="<?php echo e(old('keterangan')); ?>">
            </div>
            <div class="col">
                <input type="date" name="tanggal" id="tanggal" class="form-control" placeholder="Tanggal Transaksi"
                    required value="<?php echo e(old('tanggal')); ?>">
            </div>
        </div>

        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>

    <script>
        // Fungsi untuk mengisi otomatis "Kode Pembayaran" dengan "TPK"
        function setKodePembayaran() {
            document.getElementById('kd_pembayaran').value = 'TPK-';
        }

        // Panggil fungsi setKodePembayaran saat halaman dimuat
        window.onload = setKodePembayaran;
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Pembayaran'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/pembayaran/create.blade.php ENDPATH**/ ?>