

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center align-items-center mt-4">
        <?php if($metode_pembayaran->count() > 0): ?>
            <?php $__currentLoopData = $metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h1 class="text-dark font-weight-bold" style="font-size: 24px;"><?php echo e($row->metode_pembayaran); ?></h1>
                            <hr />
                            <h6 class="text-muted">Rp. <?php echo e($row->saldo); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <p class="text-muted">Saldo not found</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">10 Daftar Produk Terlaris</h4>
                </div>
                <div class="card-body">
                    <canvas id="chartpenjualan"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Pengeluaran</h4>
                </div>
                <div class="card-body">
                    <canvas id="chart_pengeluaran"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center mt-4">
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Piutang</h4>
                </div>
                <div class="card-body">
                    <h1 Rp. <?php echo e($sisa_piutang); ?></h1>
                        <hr />
                        <h6>Rp. <?php echo e($sisa_piutang); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Utang</h4>
                </div>
                <div class="card-body">
                    <h1 Rp. <?php echo e($sisa_utang); ?></h1>
                        <hr />
                        <h6>Rp. <?php echo e($sisa_utang); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Penjualan</h4>
                </div>
                <div class="card-body">
                    <h1 Rp. <?php echo e($total_penjualan); ?></h1>
                        <hr />
                        <h6>Rp. <?php echo e($total_penjualan); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Laba Kotor</h4>
                </div>
                <div class="card-body">
                    <h1 Rp. <?php echo e($total_laba_kotor); ?></h1>
                        <hr />
                        <h6>Rp. <?php echo e($total_laba_kotor); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title text-center">Laba Bersih</h4>
                </div>
                <div class="card-body">
                    <hr>
                    <h6>Rp. <?php echo e($laba_bersih); ?></h6>
                </div>
            </div>
        </div>
    </div>

    <script>
        // CHART PENJUALAN
        var ctx = document.getElementById('chartpenjualan').getContext('2d');

        // Extract data nama produk dan total qty ke dalam dua array terpisah
        var productNames = <?php echo json_encode($penjualanData->pluck('nama')->toArray()); ?>;
        var totalQty = <?php echo json_encode($penjualanData->pluck('total_qty')->toArray()); ?>;

        var chartpenjualan = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: productNames,
                datasets: [{
                        label: 'Qty',
                        data: totalQty,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    },

                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <script>
        // CHART PENGELUARAN
        // Data dari controller
        var chart_pengeluaran = <?php echo json_encode($chart_pengeluaran); ?>;

        // Ekstraksi data untuk chart
        var labels = chart_pengeluaran.map(function(item) {
            return item.keterangan;
        });
        var values = chart_pengeluaran.map(function(item) {
            return item.jml_pembayaran;
        });

        // Menggambar chart menggunakan Chart.js
        var ctx = document.getElementById('chart_pengeluaran').getContext('2d');
        var chart_pengeluaran = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Jumlah Pembayaran',
                    data: values,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/index.blade.php ENDPATH**/ ?>