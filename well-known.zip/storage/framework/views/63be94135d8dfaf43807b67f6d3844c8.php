

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Jenis Transaksi</h1>
    </div>
    <div class="row">
        <h5 class="mb-2"></h5>
        <a href="<?php echo e(route('jenis_transaksi.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus"></i> Tambah Data
        </a>
    </div>

    <hr />
    
    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Jenis Transaksi</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($jenis_transaksi->count() > 0): ?>
                <?php $__currentLoopData = $jenis_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($row->jenis_transaksi); ?></td>
                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">

                                <a href="<?php echo e(route('jenis_transaksi.edit', $row->id)); ?>" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('jenis_transaksi.destroy', $row->id)); ?>" method="POST"
                                    class="btn btn-danger p-0"
                                    onsubmit="return confirm('Anda yakin ingin menghapus data ini ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger m-0">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">jenis_transaksi not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Jenis Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/jenis_transaksi/index.blade.php ENDPATH**/ ?>