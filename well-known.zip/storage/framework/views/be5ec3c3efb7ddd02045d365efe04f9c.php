

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1> Tambah Jenis Transaksi</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('jenis_transaksi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="col m-2">
            <label class="form-label">Jenis Transaksi</label>
            <input type="text" name="jenis_transaksi" class="form-control" placeholder="Jenis Transaksi" required
                value="<?php echo e(old('jenis_transaksi')); ?>">
            
        </div>
        <div class="row m-2">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Tambah Jenis Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/jenis_transaksi/create.blade.php ENDPATH**/ ?>