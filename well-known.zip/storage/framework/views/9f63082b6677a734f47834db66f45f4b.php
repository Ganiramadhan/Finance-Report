

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Edit Customer</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('customer.update', $customer->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($customer->nama); ?>"
                    required>

            </div>
            <div class="col mb-3">
                <label class="form-label">Saldo Awal Piutang</label>
                <input type="number" name="saldo_awal_piutang" class="form-control" placeholder="Saldo Awal Piutang"
                    value="<?php echo e($customer->saldo_awal_piutang); ?>" required>

            </div>
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat"
                    value="<?php echo e($customer->alamat); ?>" required>
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="no_telepon" class="form-control" placeholder="Nomor Telepon"
                    value="<?php echo e($customer->no_telepon); ?>" required>
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Edit Customer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/customer/edit.blade.php ENDPATH**/ ?>