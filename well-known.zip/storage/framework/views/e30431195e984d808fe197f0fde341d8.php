

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Detail Transaksi</h1>
    </div>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Kode Transaksi</label>
            <input type="text" name="penerima" class="form-control" placeholder="Penerima"
                value="<?php echo e($transaksi->kd_transaksi); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jenis Transaksi</label>
            <input type="text" name="nama" class="form-control" placeholder="Jenis Pengeluaran"
                value="<?php echo e($transaksi->jenis_transaksi->jenis_transaksi); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Keterangan</label>
            <input type="text" name="keterangan" class="form-control" placeholder="keterangan"
                value="<?php echo e($transaksi->keterangan); ?>" readonly>
        </div>

        <div class="col mb-3">
            <label class="form-label">Jumlah</label>
            <input type="text" name="jumlah" class="form-control" placeholder="Nomor Telepon"
                value="<?php echo e('Rp ' . number_format($transaksi->jumlah, 0, ',', '.')); ?>" readonly>
        </div>
    </div>
    <div class="row">


    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Tanggal Transaksi</label>
            <input type="date" name="tanggal" class="form-control" placeholder="Tanggal Transaksi"
                value="<?php echo e($transaksi->tanggal); ?>" readonly>
        </div>

    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Created At</label>
            <input type="text" name="created_at" class="form-control" placeholder="Created At"
                value="<?php echo e($transaksi->created_at); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Updated At</label>
            <input type="text" name="updated_at" class="form-control" placeholder="Updated At"
                value="<?php echo e($transaksi->updated_at); ?>" readonly>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Detail Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/transaksi/show.blade.php ENDPATH**/ ?>