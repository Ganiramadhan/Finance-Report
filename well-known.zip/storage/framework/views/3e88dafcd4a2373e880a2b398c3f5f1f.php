<style>
    .nav-item.active {
        background-color: #007bff;
        color: #fff;
    }
</style>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="#">User</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/admin">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('product.index')); ?>">Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('customer.index')); ?>">Customer</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('supplier.index')); ?>">Supplier</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('transaksi.index')); ?>">Transaksi</a>
                </li>
                <li class="nav-item">
                    <form action="/logout" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary">Logout</button>
                    </form>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/layouts/user-navbar.blade.php ENDPATH**/ ?>