

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Detail Penjualan</h1>
    </div>
    <hr />

    <form>
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Customer</label>
                <input type="text" class="form-control" placeholder="Customer" value="<?php echo e($penjualan->customer->nama); ?>"
                    readonly>
            </div>
            <div class="col-md-4">
                <label class="form-label">Jenis Produk</label>
                <input type="text" class="form-control" placeholder="Jenis Produk"
                    value="<?php echo e($penjualan->product->nama); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Jumlah Produk</label>
                <input type="text" class="form-control" placeholder="Jumlah" value="<?php echo e($penjualan->qty); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Satuan</label>
                <input type="text" class="form-control" placeholder="Satuan" value="<?php echo e($penjualan->product->satuan); ?>"
                    readonly>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Total Harga</label>
                <input type="text" class="form-control" placeholder="Total Harga"
                    value="<?php echo e('Rp ' . number_format($penjualan->total_belanja, 0, ',', '.')); ?>" readonly>
            </div>
            <div class="col-md-4">
                <label class="form-label">Metode Pembayaran</label>
                <input type="text" class="form-control" placeholder="Metode Pembayaran"
                    value="<?php echo e($penjualan->metode_pembayaran->metode_pembayaran); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Diskon</label>
                <input type="text" class="form-control" placeholder="Diskon"
                    value="<?php echo e('Rp ' . number_format($penjualan->diskon, 0, ',', '.')); ?>" readonly>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-2">
                <label class="form-label">Total Bayar</label>
                <input type="text" class="form-control" placeholder="Total Bayar"
                    value="<?php echo e('Rp ' . number_format($penjualan->total_bayar, 0, ',', '.')); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Pembayaran</label>
                <input type="text" class="form-control" placeholder="Pembayaran"
                    value="<?php echo e('Rp ' . number_format($penjualan->pembayaran, 0, ',', '.')); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Utang</label>
                <input type="text" class="form-control" placeholder="Utang"
                    value="<?php echo e('Rp ' . number_format($penjualan->piutang, 0, ',', '.')); ?>" readonly>
            </div>
            <div class="col-md-2">
                <label class="form-label">Tanggal Transaksi</label>
                <input type="text" class="form-control" placeholder="Tanggal Transaksi"
                    value="<?php echo e($penjualan->tanggal); ?>" readonly>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Created At</label>
                <input type="text" class="form-control" placeholder="Created At" value="<?php echo e($penjualan->created_at); ?>"
                    readonly>
            </div>
            <div class="col-md-6">
                <label class="form-label">Updated At</label>
                <input type="text" class="form-control" placeholder="Updated At" value="<?php echo e($penjualan->updated_at); ?>"
                    readonly>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Detail Penjualan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/admin/penjualan/show.blade.php ENDPATH**/ ?>