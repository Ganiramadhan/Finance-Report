

<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Edit Transaksi</h1>
    </div>
    <hr />
    <form action="<?php echo e(route('transaksi.update', $transaksi->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">

            <div class="col mb-3">
                <label class="form-label">Kode Transaksi</label>
                <input type="text" name="kd_transaksi" class="form-control" placeholder="Kode Transaksi" id="kd_transaksi"
                    value="<?php echo e($transaksi->kd_transaksi); ?>" required readonly>
            </div>
            <div class="col mb-3">
                <label class="form-label">Jenis Pengeluaran</label>
                <select class="form-control" id="jenis_transaksi_id" name="jenis_transaksi_id" required>
                    <option value="">Pilih Jenis Transaksi</option>
                    <?php $__currentLoopData = $data_jenis_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == $transaksi->jenis_transaksi_id): ?> selected <?php endif; ?>>
                            <?php echo e($item->jenis_transaksi); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col mb-3">
                <label class="form-label">Metode Pembayaran</label>
                <select class="form-control" id="metode_pembayaran_id" name="metode_pembayaran_id" required>
                    <option value="">Metode Pembayaran</option>
                    <?php $__currentLoopData = $data_metode_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == $transaksi->metode_pembayaran_id): ?> selected <?php endif; ?>>
                            <?php echo e($item->metode_pembayaran); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col mb-3">
                <label class="form-label">Keterangan</label>
                <input type="text" name="keterangan" class="form-control" placeholder="keterangan" id="keterangan"
                    value="<?php echo e($transaksi->keterangan); ?>" required>
            </div>


            <div class="row">
                <div class="col mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="jumlah" class="form-control" placeholder="jumlah" id="jumlah"
                        value="<?php echo e($transaksi->jumlah); ?>"required>
                </div>

                <div class="col mb-3">
                    <label class="form-label">Tanggal Pembayaran</label>
                    <input type="date" name="tanggal" class="form-control" placeholder="tanggal" id="tanggal"
                        value="<?php echo e($transaksi->tanggal); ?>" required>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-success">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', ['title' => 'Edit Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/transaksi/edit.blade.php ENDPATH**/ ?>