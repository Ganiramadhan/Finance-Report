<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Testing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>

    <!-- Tambahkan link ke file CSS Alertify -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs/build/css/alertify.min.css" />

    <!-- Tambahkan link ke file CSS tema Alertify (opsional) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs/build/css/themes/default.min.css" />

    <!-- Tambahkan skrip JavaScript Alertify -->
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs/build/alertify.min.js"></script>


    <!-- Tambahkan link ke file CSS Toastr -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

    <!-- Tambahkan skrip JavaScript Toastr -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">
    <script src="../js/Chart.js"></script>


</head>

<body>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container py-5">
        <?php echo $__env->yieldContent('body'); ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
</body>


<script>
    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');
        var hargaHiddenInput = document.getElementById('hrg_jual_hidden');

        // Saat nilai elemen select berubah
        productSelect.addEventListener('change', function() {
            // Ambil harga dari atribut data-hrg-jual yang ada di opsi yang dipilih
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var harga = selectedOption.getAttribute('data-hrg-jual');

            // Setel nilai input harga yang bisa dilihat
            hargaInput.value = harga;

            // Setel nilai input harga yang tersembunyi
            hargaHiddenInput.value = harga;
        });
    });


    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');

        // Fungsi untuk mengatur harga berdasarkan pilihan produk
        function setHarga() {
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var harga = selectedOption.getAttribute('data-hrg-jual');
            hargaInput.value = harga;
        }

        // Panggil fungsi setHarga saat dokumen dimuat dan saat pilihan produk berubah
        setHarga();
        productSelect.addEventListener('change', setHarga);
    });



    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');
        var jumlahInput = document.getElementById('jumlah');
        var totalHargaInput = document.getElementById('total');

        // Fungsi untuk mengupdate harga berdasarkan pilihan produk
        function updateHarga() {
            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var harga = parseFloat(selectedOption.getAttribute('data-hrg-jual'));
            hargaInput.value = harga;
            hitungTotalHarga();
        }

        // Fungsi untuk menghitung total harga berdasarkan harga dan jumlah
        function hitungTotalHarga() {
            var harga = parseFloat(hargaInput.value);
            var jumlah = parseInt(jumlahInput.value);
            var totalHarga = harga * jumlah;
            totalHargaInput.value = totalHarga.toFixed(2); // Mengatur jumlah desimal
        }

        // Panggil fungsi updateHarga saat dokumen dimuat
        updateHarga();

        // Tambahkan event listener untuk pilihan produk
        productSelect.addEventListener('change', updateHarga);

        // Tambahkan event listener untuk input jumlah
        jumlahInput.addEventListener('input', hitungTotalHarga);
    });


    // Saat dokumen telah dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var productSelect = document.getElementById('product_id');
        var hargaInput = document.getElementById('hrg_jual');
        var jumlahInput = document.getElementById('jumlah');
        var totalHargaInput = document.getElementById('total');
        var editButton = document.getElementById('editButton'); // Ganti dengan ID tombol "Edit" yang sesuai

        // Fungsi untuk mengupdate total harga
        function updateTotalHarga() {
            var harga = parseFloat(hargaInput.value);
            var jumlah = parseInt(jumlahInput.value);
            var totalHarga = harga * jumlah;
            totalHargaInput.value = totalHarga.toFixed(2); // Mengatur jumlah desimal
        }

        // Panggil fungsi updateTotalHarga saat dokumen dimuat
        updateTotalHarga();

        // Tambahkan event listener ke tombol "Edit"
        editButton.addEventListener('click', function() {
            // Panggil kembali fungsi updateTotalHarga saat tombol "Edit" diklik
            updateTotalHarga();
        });
    });

    toastr.options = {
        "positionClass": "toast-top-right", // Atur posisi notifikasi
        "showDuration": "300", // Durasi tampil notifikasi (dalam milidetik)
        "hideDuration": "1000", // Durasi sembunyi notifikasi (dalam milidetik)
        "timeOut": "5000", // Waktu otomatis menutup notifikasi (dalam milidetik)
        "extendedTimeOut": "1000", // Durasi tambahan jika notifikasi dihover (dalam milidetik)
    };

    $(document).ready(function() {
        // Cek apakah ada pesan sukses dalam variabel JavaScript
        var successMessage = "<?php echo e(Session::get('success')); ?>";

        if (successMessage) {
            // Tampilkan pesan sukses menggunakan Toastr
            toastr.success(successMessage);
        }
    });

    $(document).ready(function() {
        // Cek apakah ada pesan kesalahan dalam variabel JavaScript
        var errorMessage = "<?php echo e(Session::get('error')); ?>";

        if (errorMessage) {
            // Tampilkan pesan kesalahan menggunakan Toastr
            toastr.error(errorMessage);
        }
    });
</script>




</html>
<?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/layouts/app.blade.php ENDPATH**/ ?>