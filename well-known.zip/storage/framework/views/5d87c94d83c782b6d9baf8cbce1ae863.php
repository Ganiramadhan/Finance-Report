

<?php $__env->startSection('body'); ?>
    <h5 class="mb-0">Tambah Data Metode Pembayaran</h5>
    <hr />
    <form action="<?php echo e(route('metode_pembayaran.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="metode_pembayaran" class="form-control" placeholder="Nama">
            </div>

        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/admin/metode_pembayaran/create.blade.php ENDPATH**/ ?>