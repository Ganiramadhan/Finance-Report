

<?php $__env->startSection('body'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="mb-0">Data Customer Admin</h5>
        <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus"></i> Tambah Customer
        </a>
    </div>
    <div class="form-group mt-2">
        <input type="text" name="search" id="search" class="form-control" placeholder="Cari Produk" />
    </div>
    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Saldo Awal Piutang</th>
                <th>Nomor Telepon</th>
                <th>Alamat</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($customer->count() > 0): ?>
                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($row->nama); ?></td>
                        <td class="align-middle"><?php echo e('Rp ' . number_format($row->saldo_awal_piutang, 0, ',', '.')); ?></td>
                        <td class="align-middle"><?php echo e($row->no_telepon); ?></td>
                        <td class="align-middle"><?php echo e($row->alamat); ?></td>
                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('customer.show', $row->id)); ?>" type="button" class="btn btn-secondary">
                                    <i class="fas fa-info-circle"></i>
                                </a>

                                <a href="<?php echo e(route('customer.edit', $row->id)); ?>" type="button" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('customer.destroy', $row->id)); ?>" method="POST"
                                    class="btn btn-danger p-0"
                                    onsubmit="return confirm('Anda yakin ingin menghapus data ??')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger m-0">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>

                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Customer not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views//admin/customer/index.blade.php ENDPATH**/ ?>