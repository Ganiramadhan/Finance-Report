<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> Laporan Keuangan
    </div>
    <div class="footer-right">
    </div>
</footer>
<?php /**PATH C:\Users\ganyr\Music\Laravel\Login Multi Role\resources\views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>