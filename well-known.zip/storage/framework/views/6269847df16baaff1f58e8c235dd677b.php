<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> Laporan Keuangan
    </div>
    <div class="footer-right">
    </div>
</footer>
<?php /**PATH /home/megt1363/public_html/keuangan.megamaster.id/resources/views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>